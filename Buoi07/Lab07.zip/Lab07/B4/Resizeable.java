public interface Resizeable
{
    public void resize(int percent);
}